import 'package:flutter/material.dart';

class UserState with ChangeNotifier {
  bool _isLoggedIn = false;

  bool get isLoggedIn => _isLoggedIn;

  void logIn() {
    _isLoggedIn = true;
    notifyListeners();
  }

  void logOut() {
    _isLoggedIn = false;
    notifyListeners();
  }

  void signUp() {
    _isLoggedIn = true;
    notifyListeners();
  }
}

import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'user_state.dart';
import 'header.dart';

class RpiScreen extends StatefulWidget {
  final String name;

  const RpiScreen({required this.name, super.key});

  @override
  RpiScreenState createState() => RpiScreenState();
}

class RpiScreenState extends State<RpiScreen> {
  Map<String, dynamic>? piData;
  bool isLoading = true;
  String? errorMessage;

  @override
  void initState() {
    super.initState();
    fetchRaspberryPiData(widget.name);
  }

  Future<void> fetchRaspberryPiData(String piName) async {
    final url = 'http://$piName.gard.codexenmo.no/location';
    setState(() {
      isLoading = true;
      errorMessage = null;
    });

    try {
      final response = await http.get(Uri.parse(url));
      if (response.statusCode == 200) {
        setState(() {
          piData = json.decode(response.body);
          isLoading = false;
        });
      } else {
        setState(() {
          errorMessage =
              'Failed to load data. Status code: ${response.statusCode}';
          isLoading = false;
        });
      }
    } catch (e) {
      setState(() {
        errorMessage =
            'Controller does not exist or you don\'t have access to it';
        isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final isLoggedIn = context.watch<UserState>().isLoggedIn;

    return Scaffold(
      appBar: const Header(),
      body: Center(
        child: isLoggedIn
            ? Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        IconButton(
                          icon: const Icon(Icons.arrow_back),
                          onPressed: () => context.canPop()
                              ? context.pop()
                              : context.go('/'),
                        ),
                        const Text(
                          'Details',
                          style: TextStyle(
                            fontSize: 24,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        const SizedBox(
                            width: 48), // Placeholder to align with back button
                      ],
                    ),
                    const SizedBox(height: 16),
                    isLoading
                        ? const CircularProgressIndicator()
                        : errorMessage != null
                            ? Text(errorMessage!)
                            : piData != null
                                ? Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Text('Battery: ${piData!['battery']}%'),
                                      Text('City: ${piData!['city']}'),
                                      Text('Date: ${piData!['date']}'),
                                      Text('ID: ${piData!['id']}'),
                                      Text(
                                          'Solar Panel Wattage: ${piData!['solar_panel_wattage']} W'),
                                    ],
                                  )
                                : const Text('No data available.'),
                  ],
                ),
              )
            : const Text('Please log in to view details.'),
      ),
    );
  }
}

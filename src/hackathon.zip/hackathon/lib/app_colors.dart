import 'package:flutter/material.dart';

class AppColors {
  //Main colors
  static final Color primaryColor = Colors.grey.shade500;
  static final Color secondaryColor = Colors.grey.shade700;
  static final Color tertiaryColor = Colors.grey.shade100;
  static final Color backgroundColor = Colors.grey.shade800;

  static final Color logoColor = Colors.grey.shade100;
  static final Color textColor = Colors.grey.shade500;
  static final Color hoverColor = Colors.grey.shade100;
  static final Color searchBarBackgroundColor = Colors.grey.shade200;
}

import 'package:flutter/material.dart';
import 'package:hackathon/app_colors.dart';

class AppTheme {
  static final Color baseTextColor = AppColors.textColor;

  static final theme = ThemeData(
    iconButtonTheme: IconButtonThemeData(
      style: ButtonStyle(
        iconColor: WidgetStatePropertyAll(AppColors.textColor),
        overlayColor: const WidgetStatePropertyAll(Colors.transparent),
      ),
    ),

    // Background colors
    scaffoldBackgroundColor: AppColors.backgroundColor,
    appBarTheme: AppBarTheme(backgroundColor: AppColors.backgroundColor),

    // Text color
    textTheme: TextTheme(
      displayLarge: TextStyle(color: baseTextColor),
      displayMedium: TextStyle(color: baseTextColor),
      displaySmall: TextStyle(color: baseTextColor),
      headlineLarge: TextStyle(color: baseTextColor),
      headlineMedium: TextStyle(color: baseTextColor),
      headlineSmall: TextStyle(color: baseTextColor),
      titleLarge: TextStyle(color: baseTextColor),
      titleMedium: TextStyle(color: baseTextColor),
      titleSmall: TextStyle(color: baseTextColor),
      bodyLarge: TextStyle(color: baseTextColor),
      bodyMedium: TextStyle(color: baseTextColor),
      bodySmall: TextStyle(color: baseTextColor),
      labelLarge: TextStyle(color: baseTextColor),
      labelMedium: TextStyle(color: baseTextColor),
      labelSmall: TextStyle(color: baseTextColor),
    ),

    // Input fields
    inputDecorationTheme: InputDecorationTheme(
      focusedBorder: UnderlineInputBorder(
        borderSide: BorderSide(
          color: baseTextColor,
        ),
      ),
      enabledBorder: UnderlineInputBorder(
        borderSide: BorderSide(
          color: baseTextColor,
        ),
      ),
      labelStyle: TextStyle(
        color: baseTextColor,
      ),
      hintStyle: TextStyle(
        color: baseTextColor,
      ),
      prefixIconColor: baseTextColor,
    ),

    // Cursor in input fields
    textSelectionTheme: TextSelectionThemeData(
      cursorColor: baseTextColor,
    ),

    // Buttons
    textButtonTheme: TextButtonThemeData(
      style: TextButton.styleFrom().copyWith(overlayColor:
          WidgetStateProperty.resolveWith<Color?>(
        (Set<WidgetState> states) {
          return Colors.transparent;
        },
      ), foregroundColor:
          WidgetStateProperty.resolveWith<Color?>((Set<WidgetState> states) {
        return AppColors.textColor;
      })),
    ),
  );
}

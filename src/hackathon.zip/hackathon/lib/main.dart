import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';
import 'user_state.dart';
import 'home_page.dart';
import 'login_screen.dart';
import 'signup_screen.dart';
import 'rpi_screen.dart';
import 'settings_screen.dart';
import 'app_theme.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(
    options: const FirebaseOptions(
        apiKey: "AIzaSyCFlJFCPMUMV4GbfmE8Y2_evqHFeGQe-x8",
        authDomain: "enmoai.firebaseapp.com",
        projectId: "enmoai",
        storageBucket: "enmoai.appspot.com",
        messagingSenderId: "394997652615",
        appId: "1:394997652615:web:4b5025cb34fde79a45ac22",
        measurementId: "G-0K9Y5YW64Q"),
  );
  runApp(
    ChangeNotifierProvider(
      create: (_) => UserState(),
      child: const MainApp(),
    ),
  );
}

class MainApp extends StatelessWidget {
  const MainApp({super.key});

  @override
  Widget build(BuildContext context) {
    final GoRouter router = GoRouter(
      routes: [
        GoRoute(path: '/', builder: (context, state) => const HomePage()),
        GoRoute(
            path: '/login',
            builder: (context, state) => LoginScreen(
                onLoginSuccess: () => context.read<UserState>().logIn())),
        GoRoute(
            path: '/signup',
            builder: (context, state) => SignupScreen(
                onSignupSuccess: () => context.read<UserState>().signUp())),
        GoRoute(
            path: '/settings',
            builder: (context, state) => const SettingsScreen()),
        GoRoute(
            path: '/rpi/:name',
            builder: (context, state) =>
                RpiScreen(name: state.pathParameters['name']!)),
      ],
    );

    return MaterialApp.router(
      theme: AppTheme.theme,
      routerConfig: router,
    );
  }
}

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:go_router/go_router.dart';
import 'user_state.dart';
import 'header.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  HomePageState createState() => HomePageState();
}

class HomePageState extends State<HomePage> {
  final TextEditingController _searchController = TextEditingController();

  void _search() {
    final searchInput = _searchController.text.trim();
    if (searchInput.isNotEmpty) {
      context.go('/rpi/$searchInput'); // Navigate using GoRouter
    }
  }

  @override
  Widget build(BuildContext context) {
    final isLoggedIn = context.watch<UserState>().isLoggedIn;

    return Scaffold(
      appBar: const Header(),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: isLoggedIn
            ? Column(
                children: [
                  TextField(
                    controller: _searchController,
                    decoration: const InputDecoration(
                      hintText: 'Search for controller...',
                      prefixIcon: Icon(Icons.search),
                    ),
                    onSubmitted: (_) => _search(), // Trigger search on enter
                  ),
                ],
              )
            : const Center(
                child: Text('Please log in to access features.'),
              ),
      ),
    );
  }
}

import 'package:flutter/material.dart';
import 'package:hackathon/logo.dart';
import 'package:provider/provider.dart';
import 'package:go_router/go_router.dart';
import 'user_state.dart';

class Header extends StatelessWidget implements PreferredSizeWidget {
  const Header({super.key});

  @override
  Widget build(BuildContext context) {
    final userState = context.watch<UserState>();

    return AppBar(
      title: Row(
        children: [
          const Logo(), // Logo stays on the left
          const Spacer(), // Pushes other actions to the right
          IconButton(
            icon: const Icon(Icons.settings),
            onPressed: () =>
                context.go('/settings'), // Navigate to settings page
          ),
          if (!userState.isLoggedIn) ...[
            TextButton(
              onPressed: () => context.go('/login'), // Navigate to login page
              child: const Text('Login'),
            ),
            TextButton(
              onPressed: () => context.go('/signup'), // Navigate to signup page
              child: const Text('Signup'),
            ),
          ] else ...[
            TextButton(
              onPressed: () {
                userState.logOut();
                context.go('/'); // Navigate to home after logout
              },
              child: const Text('Logout'),
            ),
          ],
        ],
      ),
    );
  }

  @override
  Size get preferredSize => const Size.fromHeight(kToolbarHeight);
}
